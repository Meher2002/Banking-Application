import React from 'react';
import Header from './top/main.jsx';
import Main from './Index/main.jsx';

const FinancialCalc = () => (
  <>
    <Header />
    <Main />
  </>
);

export default FinancialCalc;
