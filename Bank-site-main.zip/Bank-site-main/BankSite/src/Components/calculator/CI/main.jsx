import React, { useState, useEffect } from 'react';
import { withStyles } from '@material-ui/core/styles';
import Grid from '@material-ui/core/Grid';
import TextField from '@material-ui/core/TextField';
import MenuItem from '@material-ui/core/MenuItem';
import Button from '@material-ui/core/Button';
import CircularProgress from '@material-ui/core/CircularProgress';

import  calculateCompoundInterest  from '../miniComponents/calculateCI';
import Result from '../output/main';

const styles = theme => ({
  root: {
    padding: 16
  },
  input: {
    width: '100%'
  },
  calcButton: {
    width: '100%',
    marginBottom: 16,
    [theme.breakpoints.up('sm')]: {
      width: '48%',
      marginRight: 11,
      marginBottom: 0
    }
  },
  resetButton: {
    width: '100%',
    [theme.breakpoints.up('sm')]: {
      width: '48%',
      marginLeft: 11
    }
  },
  buttonProgress: {
    position: 'absolute',
    marginTop: 8,
    marginLeft: -150
  }
});

const CompoundInterest = ({ classes }) => {
  const [state, setState] = useState({
    initialInvestment: '',
    interestRate: '',
    calculationPeriod: '',
    calculationPeriodType: 1,
    compoundInterval: 12,
    regularInvestment: '',
    isCalculating: false,
    isResetting: false,
    resultData: [
      { name: 'Initial Investment', value: 0 },
      { name: 'Regular Investment', value: 0 },
      { name: 'Interest Earned', value: 0 },
      { name: 'Total', value: 0 }
    ]
  });

  useEffect(() => {
    const storedData = JSON.parse(localStorage.getItem('compoundInterest'));
    if (storedData) {
      setState(prevState => ({ ...prevState, ...storedData }));
    }
  }, []);

  const handleChange = e => {
    setState({ ...state, [e.target.name]: Number(e.target.value) });
  };

  const handleSubmit = e => {
    e.preventDefault();

    setState(prevState => ({ ...prevState, isCalculating: true }));

    setTimeout(() => {
      const {
        initialInvestment,
        interestRate,
        calculationPeriodType,
        compoundInterval,
        regularInvestment,
        resultData
      } = state;

      let { calculationPeriod } = state;
      calculationPeriod = calculationPeriod / calculationPeriodType / 1;

      const { P, PMT, I, A } = calculateCompoundInterest(
        initialInvestment,
        interestRate,
        calculationPeriod,
        compoundInterval,
        regularInvestment
      );

      resultData[0].value = P;
      resultData[1].value = PMT;
      resultData[2].value = I;
      resultData[3].value = A;

      setState(prevState => ({
        ...prevState,
        isCalculating: false,
        resultData
      }));

      // this.props.scrollBottom(); // Assuming this function is still available
    }, 2000);
  };

  const handleReset = e => {
    setState(prevState => ({ ...prevState, isResetting: true }));

    setTimeout(() => {
      setState(prevState => ({
        ...prevState,
        initialInvestment: '',
        interestRate: '',
        calculationPeriod: '',
        calculationPeriodType: 1,
        compoundInterval: 12,
        regularInvestment: '',
        isCalculating: false,
        isResetting: false,
        resultData: [
          { name: 'Initial Investment', value: 0 },
          { name: 'Regular Investment', value: 0 },
          { name: 'Interest Earned', value: 0 },
          { name: 'Total', value: 0 }
        ]
      }));

      // this.props.scrollTop(); // Assuming this function is still available
    }, 2000);
  };

  const {
    initialInvestment,
    interestRate,
    calculationPeriod,
    calculationPeriodType,
    compoundInterval,
    regularInvestment,
    isCalculating,
    isResetting,
    resultData
  } = state;

  const isFormFilled =
    initialInvestment &&
    interestRate &&
    calculationPeriod &&
    compoundInterval;

  localStorage.setItem(
    'compoundInterest',
    JSON.stringify({
      initialInvestment,
      interestRate,
      calculationPeriod,
      calculationPeriodType,
      compoundInterval,
      regularInvestment,
      resultData
    })
  );

  return (
    <main role="main">
      <form
        className={classes.root}
        noValidate
        autoComplete="off"
        onSubmit={handleSubmit}
        onReset={handleReset}
      >
        <Grid container spacing={3}>
          <Grid item xs={12}>
            <TextField
              className={classes.input}
              id="initial-investment"
              name="initialInvestment"
              label="Initial Investment"
              variant="outlined"
              type="number"
              value={initialInvestment}
              onChange={handleChange}
              disabled={isCalculating || isResetting}
            />
          </Grid>
          <Grid item xs={12}>
            <TextField
              className={classes.input}
              id="interest-rate"
              name="interestRate"
              label="Yearly Interest Rate (%)"
              variant="outlined"
              type="number"
              value={interestRate}
              onChange={handleChange}
              disabled={isCalculating || isResetting}
            />
          </Grid>
          <Grid item xs={6}>
            <TextField
              className={classes.input}
              id="calculation-period"
              name="calculationPeriod"
              label="Calculation Period"
              variant="outlined"
              type="number"
              value={calculationPeriod}
              onChange={handleChange}
              disabled={isCalculating || isResetting}
            />
          </Grid>
          <Grid item xs={6}>
            <TextField
              className={classes.input}
              id="calculation-period-type"
              name="calculationPeriodType"
              variant="outlined"
              select
              value={calculationPeriodType}
              onChange={handleChange}
              disabled={isCalculating || isResetting}
            >
              <MenuItem value={365}>Days</MenuItem>
              <MenuItem value={12}>Months</MenuItem>
              <MenuItem value={1}>Years</MenuItem>
            </TextField>
          </Grid>
          <Grid item xs={12}>
            <TextField
              className={classes.input}
              id="compound-interval"
              name="compoundInterval"
              label="Compound Interval"
              variant="outlined"
              select
              value={compoundInterval}
              onChange={handleChange}
              disabled={isCalculating || isResetting}
            >
              {/* <MenuItem value={365}>Daily</MenuItem> */}
              <MenuItem value={12}>Monthly</MenuItem>
              <MenuItem value={4}>Quarterly</MenuItem>
              <MenuItem value={2}>Half Yearly</MenuItem>
              <MenuItem value={1}>Yearly</MenuItem>
            </TextField>
          </Grid>
          <Grid item xs={12}>
            <TextField
              className={classes.input}
              id="regular-investment"
              name="regularInvestment"
              label="Regular Monthly Investment (Optional)"
              variant="outlined"
              type="number"
              value={regularInvestment}
              onChange={handleChange}
              disabled={isCalculating || isResetting}
            />
          </Grid>
          <Grid item xs={12}>
            <Button
              className={classes.calcButton}
              type="submit"
              variant="contained"
              color="primary"
              size="large"
              disabled={!isFormFilled || isCalculating}
            >
              Calculate
            </Button>
            {isCalculating && (
              <CircularProgress
                className={classes.buttonProgress}
                thickness={4}
                size={28}
              />
            )}
            <Button
              className={classes.resetButton}
              type="reset"
              variant="contained"
              size="large"
              disabled={!isFormFilled || isResetting}
            >
              Reset
            </Button>
            {isResetting && (
              <CircularProgress
                className={classes.buttonProgress}
                thickness={4}
                size={28}
              />
            )}
          </Grid>
        </Grid>
      </form>
      <Result resultData={resultData} />
    </main>
  );
};

export default withStyles(styles)(CompoundInterest);
