export { default as calculateSimpleInterest } from './calculateSI';
export { default as calculateCompoundInterest } from './calculateCI';
