import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Table from '@material-ui/core/Table';
import TableHead from '@material-ui/core/TableHead';
import TableBody from '@material-ui/core/TableBody';
import TableRow from '@material-ui/core/TableRow';
import TableCell from '@material-ui/core/TableCell';

const useStyles = makeStyles({
  tableCell: {
    fontSize: 16,
  },
});

const Result = ({ resultData }) => {
  const classes = useStyles();
console.log(resultData)
  const numberFormatter = new Intl.NumberFormat('en-US');

  const renderResultRow = (item) => (
    <TableRow key={item.name} hover>
      <TableCell className={classes.tableCell}>{item.name} </TableCell>
      <TableCell className={classes.tableCell} align="right">
        {numberFormatter.format(item.value)}
      </TableCell>
    </TableRow>
  );

  return (
    <Table aria-label="result">
      <TableHead>
        <TableRow>
          <TableCell className={classes.tableCell} colSpan={2} align="center">
            RESULT
          </TableCell>
        </TableRow>
      </TableHead>
      <TableBody>{resultData.map(renderResultRow)}</TableBody>
    </Table>
  );
};

export default Result;
