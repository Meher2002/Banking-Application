import React, { useState, useEffect } from "react";
import { Card, Row, Col } from "reactstrap";
import { local } from "./dynamicUrl";
import "./Dashboard.css";

const CardComp = ({email,cardModal}) => {
  const [accountData, setAccountData] = useState(null);
  const [cardData, setCardData] = useState(null);
 console.log(email)
  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await fetch(
          `${local}dashboard/account-details/${email}`
        );

        if (!response.ok) {
          throw new Error("Network response was not ok");
        }

        const data = await response.text();
        console.log("Response:", data);
        const parsedData = JSON.parse(data);

        setAccountData(parsedData);
      } catch (error) {
        console.error("Error fetching data:", error);
      }
    };

    fetchData();
  }, [cardModal]);
  console.log(accountData)

  useEffect(() => {
    fetch(`${local}dashboard/card-details/${accountData&&accountData.account_number}`)
      .then(response => {
        if (!response.ok) {
          throw new Error(`HTTP error! Status: ${response.status}`);
        }
        return response.json();
      })
      .then(data => {
        console.log(data);
        setCardData(data);
        localStorage.setItem('Name', data.name);
      })
      .catch(error => {
        console.error("Error fetching data:", error);
      });
  }, [cardModal,accountData]);
console.log(cardData)
  return (
    <>
      {/* {cardData && ( */}
        <Card className="overflow-hidden sm:w-2/3 sm:ml-28 lg:ml-20 lg:w-2/3 h-1/4 bg-gradient-to-r from-blue-400 to-blue-800 m-10 sm:m-20 p-2 sm:p-6 font-medium text-medium border-2 rounded-lg text-white">
          <Row>
            <Col>
              <div>
                <p className="font-weight-normal">Name</p>
                <p className="font-weight-bold">{cardData?cardData.name:"-"}</p>
              </div>
              <div className="pt-4">
                <p className="font-weight-normal">Card Number</p>
                <p className="font-weight-bold">{accountData?accountData.account_number : "-"}</p>
              </div>
              <div className=" flex justify-between pt-4">
                <div>
                  <p className="font-weight-light text-xs">Valid</p>
                  <p className="font-weight-medium text-sm">{cardData ? cardData.validity:"-"}</p>
                </div>
                <div>
                  <p className="font-weight-light text-xs">Expiry</p>
                  <p className="font-weight-medium text-sm">{cardData ? cardData.expiry:"-"}</p>
                </div>
                <div>
                  <p className="font-weight-light text-xs">CVV</p>
                  <p className="font-weight-bold text-sm">{cardData ? cardData.expiry:"-"}</p>
                </div>
              </div>
            </Col>
          </Row>
        </Card>
      {/* )} */}
    </>
  );
};

export default CardComp;
