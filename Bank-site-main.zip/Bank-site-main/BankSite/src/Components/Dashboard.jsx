import React, { useEffect, useState } from "react";
import CardComp from "./card";
import "./Dashboard.css";
import AccountDetails from "./accountDetails";
import ProfileModal from "./updateProfile";
import CardDetails from "./cardDetails";
import { GoGear } from "react-icons/go";
import { CgProfile } from "react-icons/cg";
import { GrTransaction } from "react-icons/gr";
import { GiCalculator } from "react-icons/gi";
import { FaMoneyBillTransfer } from "react-icons/fa6";
import { useNavigate, useLocation } from "react-router-dom";
import { local } from "./dynamicUrl";
const Dashboard = () => {
  const [isProfileModalOpen, setIsProfileModalOpen] = useState(false);
  const [isInnerProfileModalOpen, setIsInnerProfileModalOpen] = useState(false);
  const [isCardModalOpen, setIsCardModalOpen] = useState(false);
  const [isSettingsModalOpen, setIsSettingsModalOpen] = useState(false);
  const [editedProfile, setEditedProfile] = useState({
    Name: "",
    Email: "",
    Phone: "",
    Password: "",
    Address: "",
  });
  const [profile, setProfile] = useState("");
  const location = useLocation();
  const navigate = useNavigate();
  
  const userEmail = location?.state?.email;
  console.log(userEmail)
  const handleSendMoneyClick = () => {
    navigate("../SendMoney", { state: { userEmail: userEmail } });
  };
const handleTransactionsClick = () => {
  navigate("../transactions", { state: { email: userEmail } });
};

  console.log(userEmail);
  const toggleProfileModal = () => {
    setIsProfileModalOpen(!isProfileModalOpen);
    setEditedProfile({
      Name: "",
      Email: "",
      Phone: "",
      Password: "",
      Address: "",
    });
  };

  const toggleSettingsModal = () => {
    setIsSettingsModalOpen(!isSettingsModalOpen);
  };
  const toggleInnerProfileModal = () => {
    setIsInnerProfileModalOpen(!isInnerProfileModalOpen);
  };
  const toggleCardModal = () => {
    setIsCardModalOpen(!isCardModalOpen);
  };
  const Name = localStorage.getItem("Name");
  const FullName = localStorage.getItem("fullName");
  const Email = localStorage.getItem("email");
  const Phone = localStorage.getItem("contact");
  const Password = localStorage.getItem("password");
  const Address = localStorage.getItem("address");

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setEditedProfile({ ...editedProfile, [name]: value });
  };
  useEffect(() => {
    const apiUrl = `${local}profile/${userEmail}`;

    fetch(apiUrl)
      .then((response) => response.json())
      .then((data) => {
        setProfile(data);
        console.log(data);
      })
      .catch((error) => console.error("Error fetching data:", error));
  }, []);

  const handleUpdateInfo = () => {
    console.log("Updated Profile:", editedProfile);

    toggleInnerProfileModal();
    setIsProfileModalOpen(false);
  };
  const handleUpdateDetails = () => {
    console.log("Updated Details:" );

    toggleCardModal();
    setIsProfileModalOpen(false);
  };

  return (
    <div
      className={`w-screen h-screen lg:flex ${
        isInnerProfileModalOpen || isCardModalOpen ? "modal-open" : ""
      }`}
    >
      <div className="w-full lg:w-1/2 flex flex-col h-screen  justify-between bg-blue-400">
        <h1 className="text-white text-3xl text-center pt-10">
          Welcome {profile.name}
        </h1>
        <CardComp email={userEmail} cardModal={isCardModalOpen} />
        <div className="flex justify-between">
          <div className=" pt-10">
            <h1 className="text-3xl pl-6 pb-6" onClick={toggleProfileModal}>
              <CgProfile />
            </h1>
            <h1 className="text-3xl pl-6 pb-6" onClick={toggleSettingsModal}>
              <GoGear />
            </h1>
          </div>
          <div className="w-1/3 lg:hidden mr-10 flex flex-col bg-blue-400 ">
            <button
              className="bg-blue-400 m-2 p-2 rounded-lg hover:bg-white hover:text-black text-white border-2 border-white"
              onClick={handleTransactionsClick}
            >
              <span className="flex items-center justify-center">
                <GrTransaction />
                <h1 className="pl-6">Transactions</h1>
              </span>
            </button>
            <button
              className="bg-blue-400 m-2 p-2 rounded-lg hover:bg-white hover:text-black text-white border-2 border-white"
              onClick={()=>(window.location.href = "./financialCalculator")}
            >
              <span className="flex items-center justify-center">
                <GiCalculator />
                <h1 className="pl-6">Calculator</h1>
              </span>
            </button>
            <button
        className="bg-blue-400 m-2 p-2 rounded-lg hover:bg-white hover:text-black text-white border-2 border-white"
        onClick={handleSendMoneyClick}
      >
        <span className="flex items-center justify-center">
          <FaMoneyBillTransfer />
          <h1 className="pl-6">Send Money</h1>
        </span>
      </button>
          </div>
        </div>
      </div>
      <div className="w-screen flex flex-col h-full justify-center img bg-cover">
        <div className="w-full mb-10 bg-blue-400 hidden lg:block">
          <button
            className="relative px-8 py-2 bg-transparent rounded-lg h-16 text-white w-1/3 isolation-auto z-10 border-2 border-white before:absolute before:w-full before:transition-all before:duration-700 before:hover:w-full before:-right-full before:hover:right-0 before:rounded-full before:bg-blue-400 before:-z-10 before:aspect-square before:hover:scale-150 overflow-hidden before:hover:duration-700"
            onClick={handleTransactionsClick}
          >
            <span className="flex items-center justify-center">
              <GrTransaction />
              <h1 className="pl-6">Transactions</h1>
            </span>
          </button>
          <button
            className="relative px-8 py-2 bg-transparent rounded-lg h-16 text-white w-1/3 isolation-auto z-10 border-2 border-white
              before:absolute before:w-full before:transition-all before:duration-700 before:hover:w-full before:-right-full before:hover:right-0 before:rounded-full before:bg-blue-400 before:-z-10  before:aspect-square before:hover:scale-150 overflow-hidden before:hover:duration-700"
            onClick={() => (window.location.href = "./FinancialCalculator")}
          >
            <span className="flex items-center justify-center">
              <GiCalculator />
              <h1 className="pl-6">Calculator</h1>
            </span>
          </button>
          <button
            className="relative px-8 py-2 bg-transparent rounded-lg h-16 text-white w-1/3 isolation-auto z-10 border-2 border-white
              before:absolute before:w-full before:transition-all before:duration-700 before:hover:w-full before:-right-full before:hover:right-0 before:rounded-full before:bg-blue-400 before:-z-10  before:aspect-square before:hover:scale-150 overflow-hidden before:hover:duration-700"
            onClick={handleSendMoneyClick}
          >
            <span className="flex items-center justify-center">
              <FaMoneyBillTransfer />
              <h1 className="pl-6">Send Money</h1>
            </span>
          </button>
        </div>

        <div className="md:m-20 md:mr-60 ">
          <h1 className="text-white lg:mb-4 text-4xl md:pl-28 pt-40 lg:pt-0 text-center">
            Account Details
          </h1>
          <AccountDetails email={userEmail} />
        </div>
      </div>

      {isProfileModalOpen && (
        <div className="absolute top-80 mt-32 left-20 w-screen flex">
          <div className="bg-white border rounded-3xl p-4 w-4/6 sm:w-2/6 lg:w-1/6">
            <h1 className="text-2xl text-center">Profile</h1>
            <div>
              <h2 className="text-lg pl-10 pt-4">Name = {profile.name}</h2>
              <h2 className="text-lg pl-10 pt-4">Contact = {profile.contact}</h2>
              <h2 className="text-lg pl-10 pt-4">Email = {profile.email}</h2>
              <h2 className="text-lg pl-10 pt-4">Address = {profile.address}</h2>
            </div>
            {/* <button onClick={handleUpdateInfo} className="w-full h-10 mt-4">
              Update Info
            </button> */}
            <button onClick={handleUpdateDetails} className="w-full h-10 mt-4">
              Update Card Details
            </button>
            <button
              onClick={toggleProfileModal}
              className=" bg-red-500 w-full h-10 mt-4"
            >
              Close
            </button>
          </div>
        </div>
      )}
      {/* {isInnerProfileModalOpen && (
        <ProfileModal
          state={isInnerProfileModalOpen}
          toggleInnerProfileModal={toggleInnerProfileModal}
          Email={userEmail}
        />
      )} */}
      {isCardModalOpen && (
        <CardDetails
          state={isCardModalOpen}
          toggleInnerProfileModal={toggleCardModal}
          Email={userEmail}
        />
      )}

      {isSettingsModalOpen && (
        <div className="absolute top-80 mt-60 left-20 rounded-xl border border-t-0 w-screen border-b-0 flex">
          <div className="bg-white p-4 border rounded-3xl w-4/6 sm:w-2/6 lg:w-1/6">
            <h1 className="text-2xl text-center">Settings</h1>
            <div>
              <h2
                className="text-lg pl-10 pt-4 cursor-pointer"
                onClick={() => {
                  localStorage.clear();
                  (window.location.href = "./")
                }}
              >
                Logout
              </h2>
              <h2 className="text-lg pl-10 pt-4">Close Account</h2>
              <h2 className="text-lg pl-10 pt-4">Terms and Conditions</h2>
              <h2 className="text-lg pl-10 pt-4">Help and Support</h2>
            </div>
            <button
              onClick={toggleSettingsModal}
              className=" bg-red-500 w-full h-10 mt-4"
            >
              Close
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default Dashboard;
