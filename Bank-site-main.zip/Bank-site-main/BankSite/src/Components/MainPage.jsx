import React from "react";
import "./Dashboard.css";
import dashImg from "./dashboardIcon.jpg";
import cardImg from "./cardIcon.jpg";
import { CiCreditCard1 } from "react-icons/ci";
import { CgProfile } from "react-icons/cg";
import { MdOutlineDashboard } from "react-icons/md";
import { FaCalculator } from "react-icons/fa";
import { GrTransaction } from "react-icons/gr";
import { FaMoneyBillTransfer } from "react-icons/fa6";
import { useLocation } from "react-router-dom";
import { useNavigate } from "react-router-dom";
const MainPage = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const userEmail = location?.state?.email;
  console.log(userEmail);
  return (
    <div className="url bank bg-cover sm:flex sm:flex-col w-screen h-full sm:h-screen sm:items-center sm:justify-center">
      <div className="flex flex-col sm:flex-row w-screen h-full justify-center">
        <div
          className="text-white flex hover:bg-blue-400 text-center pt-10 pb-10 pl-10 pr-10 flex-col items-center justify-center m-10 ml-20 mt-20 mb-0 border-4 rounded-sm w-1/2 sm:w-1/5  text-3xl"
          onClick={() =>
            navigate("/dashboard", { state: { email: userEmail } })
          }
        >
          <MdOutlineDashboard className="w-80 h-32" />
          <h1 className="pt-10"> Dashboard</h1>
        </div>
        <div
          className="text-white hover:bg-blue-400 text-center pt-10 pb-10 pl-10 pr-10 flex flex-col items-center justify-center m-10 ml-20 mt-20 mb-0 border-4 rounded-sm w-1/2 sm:w-1/5 text-3xl"
          onClick={() =>
            navigate("/CardDetails", { state: { email: userEmail } })
          }
        >
          <CiCreditCard1 className="w-80 h-32" />
          <h1 className="pt-10"> Card Details</h1>
        </div>
        <div
          className="text-white hover:bg-blue-400 text-center pt-10 pb-10 pl-10 pr-10 flex flex-col items-center justify-center m-10 ml-20 mt-20 mb-0 border-4 rounded-sm w-1/2 sm:w-1/5  text-3xl"
          onClick={() =>
            navigate("/AcccountDetails", { state: { email: userEmail } })
          }
        >
          <CgProfile className="w-80 h-32" />
          <h1 className="pt-10"> Account Details</h1>
        </div>
      </div>
      <div className="flex flex-col sm:flex-row w-screen h-full mb-10 justify-center">
        {" "}
        <div
          className="text-white hover:bg-blue-400 flex flex-col pl-10 pr-10 items-center text-center pt-10 pb-10 justify-center m-10 ml-20 mt-20 mb-0 border-4 rounded-sm w-1/2 sm:w-1/5 text-3xl"
          onClick={() => (window.location.href = "./FinancialCalculator")}
        >
          <FaCalculator className="w-80 h-32" />
          <h1 className="pt-10"> Financial Calculator</h1>
        </div>
        <div
          className="text-white hover:bg-blue-400 pt-10 pb-10 pl-10 pr-10 text-center flex flex-col items-center justify-center m-10 ml-20 mt-20 mb-0 border-4 rounded-sm w-1/2 sm:w-1/5  text-3xl"
          onClick={() =>
            navigate("/transactions", { state: { email: userEmail } })
          }
        >
          <GrTransaction className="w-80 h-32" />
          <h1 className="pt-10"> Transactions</h1>
        </div>
        <div
          className="text-white hover:bg-blue-400 pt-10 pb-10 pl-10 pr-10 text-center flex flex-col items-center justify-center m-10 ml-20 mt-20 mb-0 border-4 rounded-sm w-1/2 sm:w-1/5  text-3xl"
          onClick={() =>
            navigate("/SendMoney", { state: { userEmail: userEmail } })
          }
        >
          <FaMoneyBillTransfer className="w-80 h-32" />
          <h1 className="pt-10 "> Send Money</h1>
        </div>
      </div>
    </div>
  );
};

export default MainPage;
