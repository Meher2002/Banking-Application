import React, { useState, useEffect } from 'react';
import { local } from './dynamicUrl';
import { useLocation } from 'react-router-dom';

const Transactions = () => {
  const [transactions, setTransactions] = useState([]);
  const [accountDetails, setAccountDetails] = useState([]);
  const location = useLocation();
  const userEmail = location?.state?.email;
console.log(userEmail)
  useEffect(() => {
    const fetchAccountDetails = async () => {
      try {
        const apiUrl = `${local}dashboard/account-details/${userEmail}`;
        const response = await fetch(apiUrl);
        const data = await response.json();
        setAccountDetails(data);
        console.log(data);
      } catch (error) {
        console.error('Error fetching account details:', error);
      }
    };

    if (userEmail) {
      fetchAccountDetails();
    }
  }, [userEmail]);

  useEffect(() => {
    const fetchTransactions = async () => {
      try {
        const apiUrl = `${local}transactions/${accountDetails?accountDetails.account_number:"-"}`;
        const response = await fetch(apiUrl);
        const data = await response.json();
        const updatedData = data.map((transaction) => ({
          ...transaction,
          date: new Date(transaction.time * 1000).toLocaleDateString(),
          time: new Date(transaction.time * 1000).toLocaleTimeString(),
        }));
        setTransactions(updatedData);
        console.log(updatedData);
      } catch (error) {
        console.error('Error fetching transactions:', error);
      }
    };

    fetchTransactions();
  }, [accountDetails]);
  return (
    <div>
      <h2 className='text-2xl text-center bg-#F9F9F9 font-bold'>Transactions</h2>
      {transactions && transactions.length > 0 ? (
        <table className='w-screen text-blue-400 mt-10 text-lg border-2 rounded-lg'>
          <thead>
            <tr>
              <th>Date</th>
              <th>Time</th>
              <th>Amount</th>
              <th>Transaction Type</th>
              <th>Transaction Status</th>
              <th className='hidden md:table-cell'>Transaction Id</th>
              <th className='hidden md:table-cell'>Reference Number</th>
              <th className='hidden md:table-cell'>Account Number</th>
              <th className='hidden md:table-cell'>Current Balance</th>
            </tr>
          </thead>
          <tbody>
            {transactions.map((transaction) => (
              <tr key={transaction.transaction_id} className='text-center text-black'>
                <td>{transaction.date}</td>
                <td>{transaction.time}</td>
                <td>{transaction.amount}</td>
                <td>{transaction.transaction_type}</td>
                <td>{transaction.transaction_status}</td>
                <td className='hidden md:table-cell'>{transaction.transaction_id}</td>
                <td className='hidden md:table-cell'>{transaction.reference_number}</td>
                <td className='hidden md:table-cell'>{transaction.account_number}</td>
                <td className='hidden md:table-cell'>{transaction.current_balance}</td>
              </tr>
            ))}
          </tbody>
        </table>
      ) : (
       <h1 className='text-4xl font-bold flex items-center justify-center'>
        No Transactions yet
       </h1>
      )}
    </div>
  );
};

export default Transactions;
