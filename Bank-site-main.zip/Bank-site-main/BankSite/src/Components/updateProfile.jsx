import { useState,useEffect } from "react";
import { local } from './dynamicUrl';

const ProfileModal = ({ Email, state, toggleInnerProfileModal }) => {
  const [accountData, setAccountData] = useState(null);
  const [formData, setFormData] = useState({
    account_type: "",
    account_number: 0,
    account_balance: 0,
    account_status: "",
    interest_rate: 0,
    transaction_limits: 0,
    account_opening_date: "",
    email: "",
  });

  const {
    account_type,
    account_number,
    account_balance,
    account_status,
    interest_rate,
    transaction_limits,
    account_opening_date,
    email,
  } = formData;
  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await fetch(
          `${local}dashboard/account-details/${Email}`
        );

        if (!response.ok) {
          throw new Error("Network response was not ok");
        }

        const data = await response.text();
        console.log("Response:", data);
        const parsedData = JSON.parse(data);

        setAccountData(parsedData);
      } catch (error) {
        console.error("Error fetching data:", error);
      }
    };

    fetchData();
  }, []);
  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };
  const validateFields = () => {
    const fields = Object.values(formData);
    return fields.every((field) => field !== '' && field !== null);
  };
  const handleSubmit = async () => {
    if (!validateFields()) {
        alert('Fill in all fields before proceeding.');
        return;
      }
    const apiUrl = `${local}account-details`;

    const requestBody = {
      account_type,
      account_number,
      account_balance,
      account_status,
      interest_rate,
      transaction_limits,
      account_opening_date,
      email,
    };

    try {
      const response = await fetch(apiUrl, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(requestBody),
      });

      if (response.ok) {
        console.log("Profile updated successfully!");
        prompt("profile updated successfully")
        // Additional actions after successful update
      } else {
        console.error("Error updating profile:", response.status);
        // Handle error scenarios
      }
    } catch (error) {
      console.error("Error updating profile:", error);
      prompt("fill all fields ")

      // Handle error scenarios
    }

  };


  return (
    <div>
      <div className="fixed top-0 left-0 items-center justify-center rounded-xl border border-t-0 w-screen h-screen flex">
        <div className="bg-black border rounded-3xl text-black p-4 w-1/2 sm:w-4/6 lg:w-2/6 ">
          <h1 className="text-2xl text-center text-white pb-4">Update Profile</h1>
          <div className="items-center flex flex-col">
            <input
              type="text"
              name="account_type"
              value={account_type}
              onChange={handleChange}
              placeholder="Account Type"
              className="text-lg pl-10 pt-4"
            />

            <input
              type="number"
              name="account_number"
              value={account_number? account_number:"Account Number"}
              onChange={handleChange}
              placeholder="Account Number"
              className="text-lg pl-10 pt-4"
            />

            <input
              type="number"
              name="account_balance"
              value={account_balance?account_balance:"Account Balance"}
              onChange={handleChange}
              placeholder="Account Balance"
              className="text-lg pl-10 pt-4"
            />

            <input
              type="text"
              name="account_status"
              value={account_status}
              onChange={handleChange}
              placeholder="Account Status"
              className="text-lg pl-10 pt-4"
            />

            <input
              type="number"
              name="interest_rate"
              value={interest_rate?interest_rate:"Interest Rate"}
              onChange={handleChange}
              placeholder="Interest Rate"
              className="text-lg pl-10 pt-4"
            />

            <input
              type="number"
              name="transaction_limits"
              value={transaction_limits?transaction_limits:"Transaction Limit"}
              onChange={handleChange}
              placeholder="Transaction Limits"
              className="text-lg pl-10 pt-4"
            />

            <input
              type="text"
              name="account_opening_date"
              value={account_opening_date}
              onChange={handleChange}
              placeholder="Account Opening Date"
              className="text-lg pl-10 pt-4"
            />

            <input
              type="text"
              name="email"
              value={email}
              onChange={handleChange}
              placeholder="Email"
              className="text-lg pl-10 pt-4"
            />
          </div>
          <button onClick={handleSubmit} className="w-full h-10 mt-4">
            Update Info
          </button>
          <button
            onClick={toggleInnerProfileModal}
            className="bg-red-500 w-full h-10 mt-4"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};

export default ProfileModal;
