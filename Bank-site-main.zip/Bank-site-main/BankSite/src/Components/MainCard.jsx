import React, { useState, useEffect } from "react";
import { Card, Row, Col } from "reactstrap";
import { local } from "./dynamicUrl";
import "./Dashboard.css";
import { useLocation } from 'react-router-dom';
const CardComp = () => {
  const [cardData, setCardData] = useState(null);
  const [accountData, setAccountData] = useState(null);
  const location = useLocation();
  const email = location?.state?.email;
console.log(email)
  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await fetch(
          `${local}dashboard/account-details/${email}`
        );

        if (!response.ok) {
          throw new Error("Network response was not ok");
        }

        const data = await response.text();
        console.log("Response:", data);
        const parsedData = JSON.parse(data);

        setAccountData(parsedData);
      } catch (error) {
        console.error("Error fetching data:", error);
      }
    };

    fetchData();
  }, []);
  useEffect(() => {
    fetch(`${local}dashboard/card-details/${accountData&&accountData.account_number}`)
      .then(response => {
        if (!response.ok) {
          throw new Error(`HTTP error! Status: ${response.status}`);
        }
        return response.json();
      })
      .then(data => {
        console.log(data);
        setCardData(data);
        localStorage.setItem('Name', data.name);
      })
      .catch(error => {
        console.error("Error fetching data:", error);
      });
  }, [accountData]);
  return (
    <>
     <div className="bg-blue-400 h-screen flex flex-col items-center justify-center ">
     <h1 className="text-white text-4xl pb-20"> Card Details</h1>
     {/* {cardData && ( */}
        <Card className="overflow-hidden w-screen lg:w-1/3 sm:w-2/3 sm:ml-28 lg:mt-0 lg:h-1/3 h-1/4 bg-gradient-to-r from-blue-400 to-blue-800 m-10 sm:m-20 p-2 sm:p-6 font-medium text-medium border-2 rounded-lg text-white">
          <Row>
            <Col>
              <div className="lg:text-xl ">
                <p className="font-weight-normal">Name</p>
                <p className="font-weight-bold">{cardData?cardData.name:"-"}</p>
              </div>
              <div className="lg:text-xl pt-4 lg:pt-10">
                <p className="font-weight-normal">Card Number</p>
                <p className="font-weight-bold">{accountData?accountData.account_number : "-"}</p>
              </div>
              <div className=" lg:text-xl flex justify-between pt-4 lg:pt-10">
                <div>
                  <p className="font-weight-light text-xs">Valid</p>
                  <p className="font-weight-medium text-sm">{cardData ? cardData.validity:"-"}</p>
                </div>
                <div>
                  <p className="font-weight-light text-xs">Expiry</p>
                  <p className="font-weight-medium text-sm">{cardData ? cardData.expiry:"-"}</p>
                </div>
                <div>
                  <p className="font-weight-light text-xs">CVV</p>
                  <p className="font-weight-bold text-sm">{cardData ? cardData.cvv:"-"}</p>
                </div>
              </div>
            </Col>
          </Row>
        </Card>
      {/* )} */}
     </div>
    </>
  );
};

export default CardComp;
