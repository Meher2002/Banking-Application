import { useState,useEffect } from "react";
import { local } from './dynamicUrl';

const CardDetails = ({Email, state, toggleInnerProfileModal }) => {
    const [accountData, setAccountData] = useState(null);
    const [formData, setFormData] = useState({
        name: "",
        expiry: "",
        cvv: 0,
        validity: ""
      });
      

  const {
    name,
    expiry,
    cvv,
    validity
  } = formData;

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const validateFields = () => {
    const fields = Object.values(formData);
    return fields.every((field) => field !== '' && field !== null);
  };
  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await fetch(
          `${local}dashboard/account-details/${Email}`
        );

        if (!response.ok) {
          throw new Error("Network response was not ok");
        }

        const data = await response.text();
        console.log("Response:", data);
        const parsedData = JSON.parse(data);

        setAccountData(parsedData);
      } catch (error) {
        console.error("Error fetching data:", error);
      }
    };

    fetchData();
  }, []);
  const handleSubmit = async () => {
    if (!validateFields()) {
      alert('Fill in all fields before proceeding.');
      return;
    }
  
    const apiUrl = `${local}dashboard/card-details`;
  
    const requestBody = {
        name,
        account_number: accountData.account_number,
        expiry,
        cvv,
        validity
      };
    try {
      console.log("Request Body:", requestBody);
  
      const response = await fetch(apiUrl, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(requestBody),
      });
  
      console.log("Response:", response);
  
      if (response.ok) {
        console.log("Card Details updated successfully!");
        alert("Card Details updated successfully");
      } else {
        console.error("Error updating Card Details:", response.status);
      }
    } catch (error) {
      console.error("Error updating Card Details:", error);
      prompt("Fill in all fields ");
  
    }
  };
  

  return (
    <div>
      <div className="fixed top-0 left-0 items-center justify-center rounded-xl border border-t-0 w-screen h-screen flex">
        <div className="bg-black border rounded-3xl text-black p-4 w-1/2 sm:w-4/6 lg:w-2/6 ">
          <h1 className="text-2xl text-center text-white pb-4">Update Details</h1>
          <div className="items-center flex flex-col">
            <input
              type="text"
              name="name"
              value={name}
              onChange={handleChange}
              placeholder="Name"
              className="text-lg pl-10 pt-4"
            />

            <input
            type="number"
            name="account_number"
            value={accountData ?accountData.account_number:"-"}
            placeholder="Account Number"
            className="text-lg pl-10 pt-4"
            readOnly
            />


            <input
              type="text"
              name="expiry"
              value={expiry}
              onChange={handleChange}
              placeholder="Expiry"
              className="text-lg pl-10 pt-4"
            />

            <input
              type="text"
              name="validity"
              value={validity}
              onChange={handleChange}
              placeholder="Validity"
              className="text-lg pl-10 pt-4"
            />

            <input
              type="number"
              name="cvv"
              value={cvv}
              onChange={handleChange}
              placeholder="CVV"
              className="text-lg pl-10 pt-4"
            />
          </div>
          <button onClick={handleSubmit} className="w-full h-10 mt-4">
            Update Details
          </button>
          <button
            onClick={toggleInnerProfileModal}
            className="bg-red-500 w-full h-10 mt-4"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};

export default CardDetails;
