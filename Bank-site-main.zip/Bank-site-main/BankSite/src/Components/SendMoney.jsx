import React, { useState, useEffect } from "react";
import "./SendMoneyForm.css"; // Import your CSS file for styling
import { useLocation } from "react-router-dom";
import { local } from "./dynamicUrl";
const SendMoneyForm = () => {
  const [accountData, setAccountData] = useState(null);
  const [sender, setSender] = useState("");
  const [receiver, setReceiver] = useState("");
  const [amount, setAmount] = useState("");
  const [transactionStatus, setTransactionStatus] = useState("");
  const location = useLocation();
  const email = location?.state?.userEmail;
  console.log(email);
  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await fetch(
          `${local}dashboard/account-details/${email}`
        );

        if (!response.ok) {
          throw new Error("Network response was not ok");
        }
        const data = await response.text();
        console.log("Response:", data);
        const parsedData = JSON.parse(data);

        setAccountData(parsedData);
      } catch (error) {
        console.error("Error fetching data:", error);
      }
    };

    fetchData();
  }, []);
  useEffect(() => {
    setSender(accountData && accountData.account_number);
  }, [accountData]);
  console.log(sender);
  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const apiUrl = `${local}transfer-funds`;

      const response = await fetch(apiUrl, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          sender,
          receiver,
          amount: parseInt(amount, 10),
        }),
      });

      if (!response.ok) {
        throw new Error(`HTTP error! Status: ${response.status}`);
      }

      const responseData = await response.json();
      setTransactionStatus("Transaction successful");
      console.log("Transaction successful:", responseData);
    } catch (error) {
      setTransactionStatus(`Error: ${error.message}`);
      console.error("Error sending money:", error.message);
    }
  };

  return (
    <div className="h-screen w-screen mainDiv flex">
      <div className="send-money-container bg-[#F9F9F9] ">
        <h1 className="text-center pb-10 text-2xl font-medium">
          Transfer Money
        </h1>
        <form onSubmit={handleSubmit}>
          <label>
            My Account Number:
            <input
              type="text"
              value={sender}
              readOnly // Make the input read-only since it's retrieved from the session
            />
          </label>
          <br />

          <label>
            receiver:
            <input
              type="text"
              value={receiver}
              onChange={(e) => setReceiver(e.target.value)}
            />
          </label>
          <br />

          <label>
            Amount:
            <input
              type="number"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
            />
          </label>
          <br />

          <button type="submit" className="text-white bg-blue-500 w-full h-10">
            Send Money
          </button>
        </form>

        {transactionStatus && (
          <p className="transaction-status">{transactionStatus}</p>
        )}
      </div>
    </div>
  );
};

export default SendMoneyForm;
