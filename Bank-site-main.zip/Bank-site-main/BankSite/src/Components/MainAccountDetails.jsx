import React, { useState, useEffect } from "react";
import { local } from "./dynamicUrl";
import { useLocation } from 'react-router-dom';
const AccountDetails = () => {
  const [accountData, setAccountData] = useState(null);
  const location = useLocation();
  const Email = location?.state?.email;
  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await fetch(
          `${local}dashboard/account-details/${Email}`
        );

        if (!response.ok) {
          throw new Error("Network response was not ok");
        }

        const data = await response.text();
        const parsedData = JSON.parse(data);

        setAccountData(parsedData);
      } catch (error) {
        console.error("Error fetching data:", error);
      }
    };

    fetchData();
  }, []);

  return (
   <div className="img w-screen h-screen bg-cover flex flex-col items-center justify-center ">
    <h1 className="text-white text-5xl pb-20">Account Details</h1>
     <div className="border-4 text-white p-10 lg:w-1/2 lg:mt-0 lg  pb-0 mb-0 md:mb-0 pt-6 mt-10 md:m-20 rounded-lg w-full">
      {/* {accountData && ( */}
        <>
          <div className="flex">
            <h3 className="w-1/2 text-center text-lg sm:text-xl 2xl:text-2xl pb-10 flex-col br-2 border-r-4">
              Account Type
            </h3>
            <h3 className="text-center flex-col text-xl w-1/2 ">
            {accountData? accountData.account_type : "-" }
            </h3>
          </div>
          <div className="flex">
            <h3 className="w-1/2 text-center text-lg sm:text-xl 2xl:text-2xl pb-10 flex-col br-2 mt-2 border-r-4">
              Account Number
            </h3>
            <h3 className="text-center flex-col text-xl w-1/2 ">
            {accountData? accountData.account_number : "-"}
            </h3>
          </div>
          <div className="flex">
            <h3 className="w-1/2 text-center text-lg sm:text-xl 2xl:text-2xl pb-10 flex-col br-2 mt-2 border-r-4">
              Account Balance
            </h3>
            <h3 className="text-center flex-col text-xl w-1/2 ">
            {accountData? accountData.account_balance : "-"}
            </h3>
          </div>
          <div className="flex">
            <h3 className="w-1/2 text-center text-lg sm:text-xl 2xl:text-2xl pb-10 flex-col br-2 mt-2 border-r-4">
              Account Status
            </h3>
            <h3 className="text-center flex-col text-xl w-1/2 ">
            {accountData?accountData.account_status : "-"}
            </h3>
          </div>
          <div className="flex">
            <h3 className="w-1/2 text-center text-lg sm:text-xl 2xl:text-2xl pb-10 flex-col br-2 mt-2 border-r-4">
              Interest Rate
            </h3>
            <h3 className="text-center flex-col text-xl w-1/2 ">
            {accountData? accountData.interest_rate : "-"}
            </h3>
          </div>
          <div className="flex">
            <h3 className="w-1/2 text-center text-lg sm:text-xl 2xl:text-2xl pb-10 flex-col br-2 mt-2 border-r-4">
              Transaction Limits
            </h3>
            <h3 className="text-center flex-col text-xl w-1/2 ">
            {accountData? accountData.transaction_limits : "-"}
            </h3>
          </div>
          <div className="flex">
            <h3 className="w-1/2 text-center text-lg sm:text-xl 2xl:text-2xl pb-10 flex-col br-2 mt-2 border-r-4">
              Account Opening Date
            </h3>
            <h3 className="text-center flex-col text-xl w-1/2 ">
            {accountData? accountData.account_opening_date :"-"}
            </h3>
          </div>
        </>
      {/* )} */}
    </div>
   </div>
  );
};

export default AccountDetails;
