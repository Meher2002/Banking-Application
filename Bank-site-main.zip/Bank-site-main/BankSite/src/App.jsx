import Dashboard from "./Components/Dashboard";
import Transactions from "./Components/Transactions";
import FinancialCalc from "./Components/calculator/InterestCalculator";
import SendMoneyForm from "./Components/SendMoney";
import MainPage from "./Components/MainPage.jsx";
import MainCard from "./Components/MainCard.jsx";
import MainAccountDetails from "./Components/MainAccountDetails.jsx";
import CardComp from "./Components/card.jsx";
import "./App.css";
import LoginSignin from "./Components/LoginSignin";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
function App() {
  return (
    <>
      <Router>
        <Routes>
          <Route path="/MainPage" element={<MainPage />} />
          <Route path="/CardDetails" element={<MainCard/>} />
          <Route path="/AcccountDetails" element={<MainAccountDetails />} />
          <Route path="/Dashboard" element={<Dashboard />} />
          <Route path="/Transactions" element={<Transactions />} />
          <Route path="/FinancialCalculator" element={<FinancialCalc />} />
          <Route path="/SendMoney" element={<SendMoneyForm />} />
          <Route path="/" element={<LoginSignin />} />
        </Routes>
      </Router>
    </>
  );
}

export default App;
